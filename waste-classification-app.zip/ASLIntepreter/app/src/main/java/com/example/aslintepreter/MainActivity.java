package com.example.aslintepreter; // Make sure this matches your actual package name

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 101; // Unique code

    private WebView myWebView;
    private PermissionRequest currentPermissionRequest; // To hold the web permission request

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // EdgeToEdge.enable(this); // You can keep or remove EdgeToEdge if desired
        setContentView(R.layout.activity_main); // Loads your layout with the WebView
        // The ViewCompat listener for insets might interfere with WebView layout, remove if causing issues
        /*
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        */

        myWebView = findViewById(R.id.myWebView); // Make sure the ID matches your XML

        // --- Configure WebView Settings ---
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);       // Enable JavaScript **REQUIRED**
        webSettings.setDomStorageEnabled(true);       // Enable DOM Storage (localStorage)
        webSettings.setMediaPlaybackRequiresUserGesture(false); // Allow JS to control media (important for camera)
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true); // May be needed for some JS interactions

        // --- Handle Permissions and Console Logs ---
        myWebView.setWebChromeClient(new WebChromeClient() {
            // Handle JavaScript console messages (for debugging)
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("WebViewConsole", consoleMessage.message() + " -- From line "
                        + consoleMessage.lineNumber() + " of "
                        + consoleMessage.sourceId());
                return true;
            }

            // Handle permission requests from the web page (like camera)
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                Log.d(TAG, "onPermissionRequest for " + String.join(",", request.getResources()));
                currentPermissionRequest = request; // Store the request

                // Check which permissions the web page is asking for
                // Android M and above require runtime permissions
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    // Check for Camera permission specifically
                    boolean needsCameraPermission = false;
                    for (String resource : request.getResources()) {
                        if (resource.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                            needsCameraPermission = true;
                            break;
                        }
                    }

                    if (needsCameraPermission) {
                        // Check if we already have Android permission
                        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            // Already granted, grant the web permission
                            Log.d(TAG, "Camera permission already granted by Android, granting WebView request.");
                            request.grant(request.getResources());
                            currentPermissionRequest = null;
                        } else {
                            // Need to request Android permission
                            Log.d(TAG, "Requesting Android CAMERA permission...");
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.CAMERA},
                                    CAMERA_PERMISSION_REQUEST_CODE);
                            // We will grant the WebView permission in onRequestPermissionsResult
                        }
                    } else {
                        // If other permissions are requested, grant them if appropriate or deny
                        try {
                            Log.d(TAG, "Granting non-camera permission request.");
                            request.grant(request.getResources());
                        } catch(Exception e) {
                            Log.e(TAG,"Error granting non-camera permission", e);
                        }
                        currentPermissionRequest = null;
                    }
                } else {
                    // For older Android versions, assume permission might be granted at install time
                    try {
                        Log.d(TAG, "Granting permission request on older OS.");
                        request.grant(request.getResources());
                    } catch(Exception e) {
                        Log.e(TAG,"Error granting permission on older OS", e);
                    }
                    currentPermissionRequest = null;
                }
            }
        });

        // Set a basic WebViewClient (optional, handles page navigation within the view)
        myWebView.setWebViewClient(new WebViewClient());

        // --- Load the local HTML file ---
        // Make sure index.html is in src/main/assets
        myWebView.loadUrl("file:///android_asset/index.html");
        Log.d(TAG, "Loading index.html from assets...");
    }

    // --- Handle the result of the Android Runtime Permission request ---
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Android Camera Permission granted by user
                Log.d(TAG, "Android CAMERA permission granted by user.");
                // Now grant the stored WebView permission request, if it exists
                if (currentPermissionRequest != null) {
                    Log.d(TAG, "Granting stored WebView permission request.");
                    currentPermissionRequest.grant(currentPermissionRequest.getResources());
                    currentPermissionRequest = null; // Clear the stored request
                }
                Toast.makeText(this, "Camera permission granted.", Toast.LENGTH_SHORT).show();

            } else {
                // Android Camera Permission denied by user
                Log.d(TAG, "Android CAMERA permission denied by user.");
                // Deny the stored WebView permission request
                if (currentPermissionRequest != null) {
                    Log.d(TAG, "Denying stored WebView permission request.");
                    currentPermissionRequest.deny();
                    currentPermissionRequest = null; // Clear the stored request
                }
                Toast.makeText(this, "Camera permission denied. Camera features unavailable.", Toast.LENGTH_LONG).show();
                // Handle denial - maybe show an explanation or disable camera features in JS?
            }
        }
    }

    // --- Handle Back Button Press ---
    @Override
    public void onBackPressed() {
        // If the WebView can go back in history, go back
        if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            // Otherwise, perform the default back button action (exit app)
            super.onBackPressed();
        }
    }
}